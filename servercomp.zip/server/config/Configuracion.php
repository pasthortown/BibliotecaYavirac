<?php
define("NOMBRE_CONEXION","local");